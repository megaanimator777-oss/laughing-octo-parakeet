package com.dizz.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.roundToInt

object Look {
    var cover by mutableStateOf<ImageBitmap?>(null)
    var accent by mutableStateOf(Color(0xFF9B5CFF))
    var hue by mutableFloatStateOf(220f)      // текущие значения темы (плавно ползут к целевым)
    var sat by mutableFloatStateOf(0.07f)
    var hueT by mutableFloatStateOf(220f)     // целевые значения — по обложке трека
    var satT by mutableFloatStateOf(0.07f)

    /** Один шаг плавного перехода темы. true — ещё не дошли. */
    fun moveToward(): Boolean {
        val dh = ((hueT - hue + 540f) % 360f) - 180f
        val ds = satT - sat
        if (abs(dh) < 0.6f && abs(ds) < 0.004f) { hue = hueT; sat = satT; return false }
        hue = (hue + dh * 0.12f + 360f) % 360f
        sat += ds * 0.12f
        return true
    }
}

/** Общие часы кадров: визуализация и слой обложки перерисовываются от них. */
object Clock {
    var t by mutableLongStateOf(0L)
}

/** Обложка теперь часть интерфейса плеера, а не слой поверх визуализации. */
fun coverOn() = false

/** Центр визуализации: если есть обложка — немного выше середины, чтобы обложка легла в кольцо. */
fun vizCenter(w: Float, h: Float) = if (coverOn()) Offset(w / 2f, h * 0.40f) else Offset(w / 2f, h / 2f)

fun hueShift(c: Color, d: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    return Color.hsv((((hsv[0] + d) % 360f) + 360f) % 360f, hsv[1], hsv[2])
}

object Covers {
    private val DEF = Color(0xFF9B5CFF)

    fun request(t: Track?) {
        if (t == null) { Look.cover = null; Look.accent = DEF; Look.satT = 0.07f; return }
        Look.cover = null
        Thread {
            val bmp = try { load(Engine.app, t) } catch (e: Exception) { null }
            if (App.current?.id == t.id) {
                val pal = if (bmp != null) palette(bmp) else null
                Look.cover = bmp?.asImageBitmap()
                if (pal != null) {
                    // насколько обложка вообще цветная: чёрно-белые дают почти нейтральную тему
                    val colorful = (pal[2] * 5f).coerceIn(0f, 1f)
                    Look.hueT = pal[0]
                    Look.satT = 0.07f + 0.58f * colorful * pal[1].coerceIn(0.45f, 1f)
                    Look.accent = Color.hsv(pal[0], 0.65f * colorful, 1f)
                } else {
                    Look.satT = 0.07f
                    Look.accent = DEF
                }
            }
        }.start()
    }

    private fun decode(b: ByteArray): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / s > 1024 || o.outHeight / s > 1024) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeByteArray(b, 0, b.size, o2)
    }

    fun load(ctx: Context, t: Track): Bitmap? {
        val remote = t.coverUrl
        if (remote != null) {
            val bytes = Net.bytes(remote.replace("width=300", "width=600")) ?: Net.bytes(remote)
            return if (bytes != null) decode(bytes) else null
        }
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, t.uri)
                val pic = r.embeddedPicture
                if (pic != null) { val d = decode(pic); if (d != null) return d }
            } finally { r.release() }
        } catch (e: Exception) { }
        if (Build.VERSION.SDK_INT >= 29) {
            try { return ctx.contentResolver.loadThumbnail(t.uri, android.util.Size(800, 800), null) } catch (e: Exception) { }
        }
        return null
    }

    /** Самый насыщенный и яркий оттенок обложки — для акцентного цвета интерфейса. */
    /**
     * [оттенок, насыщенность, «цветность»]. Тёмные и серые пиксели цвета не несут и не учитываются;
     * оттенок — круговое среднее в самом «весомом» секторе. Цветность ≈ доля ярких цветных пикселей.
     */
    fun palette(b: Bitmap): FloatArray {
        val s = Bitmap.createScaledBitmap(b, 32, 32, true)
        val hsv = FloatArray(3)
        val wBin = FloatArray(36)
        val sBin = FloatArray(36)
        var total = 0f
        for (y in 0 until 32) for (x in 0 until 32) {
            android.graphics.Color.colorToHSV(s.getPixel(x, y), hsv)
            val sat = hsv[1]
            val v = hsv[2]
            if (v < 0.15f || sat < 0.15f) continue
            val w = sat * v
            val bin = (hsv[0] / 10f).toInt().coerceIn(0, 35)
            wBin[bin] += w
            sBin[bin] += sat * w
            total += w
        }
        if (total <= 0f) return floatArrayOf(220f, 0f, 0f)
        var best = 0
        var bw = -1f
        for (i in 0 until 36) {
            val w = wBin[i] + 0.5f * (wBin[(i + 35) % 36] + wBin[(i + 1) % 36])
            if (w > bw) { bw = w; best = i }
        }
        var sx = 0.0
        var sy = 0.0
        var ws = 0f
        var ss = 0f
        for (d in -1..1) {
            val i = (best + d + 36) % 36
            val a = Math.toRadians(i * 10.0 + 5.0)
            sx += wBin[i] * cos(a)
            sy += wBin[i] * sin(a)
            ws += wBin[i]
            ss += sBin[i]
        }
        val hue = ((Math.toDegrees(atan2(sy, sx)) + 360.0) % 360.0).toFloat()
        return floatArrayOf(hue, if (ws > 0f) ss / ws else 0f, total / 1024f)
    }
}

/** Обложка рисуется ПОВЕРХ визуализации и вспышки. */
@Composable
fun CoverLayer() {
    val img = Look.cover
    if (!Cfg.showCover || img == null) return
    Canvas(Modifier.fillMaxSize()) {
        val tick = Clock.t
        if (tick == Long.MIN_VALUE) return@Canvas
        val w = size.width; val h = size.height
        val c = vizCenter(w, h)
        val pulse = Engine.pulse
        val d = min(w, h) * Cfg.coverSize * (1f + 0.05f * pulse)
        val side = min(img.width, img.height)
        val ox = (img.width - side) / 2; val oy = (img.height - side) / 2
        val tl = Offset(c.x - d / 2f, c.y - d / 2f)
        drawCircle(Look.accent.copy(alpha = 0.18f + 0.25f * pulse), d * 0.62f, c, blendMode = BlendMode.Plus)
        val path = Path()
        if (Cfg.coverShape == 0) path.addOval(Rect(tl, Size(d, d)))
        else path.addRoundRect(RoundRect(Rect(tl, Size(d, d)), CornerRadius(d * 0.12f)))
        clipPath(path) {
            drawImage(
                img, IntOffset(ox, oy), IntSize(side, side),
                IntOffset(tl.x.roundToInt(), tl.y.roundToInt()), IntSize(d.roundToInt(), d.roundToInt())
            )
        }
        drawPath(path, Color.White.copy(alpha = 0.25f), style = Stroke(2f))
    }
}
