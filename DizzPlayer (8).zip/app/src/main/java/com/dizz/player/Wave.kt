package com.dizz.player

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.tanh
import kotlin.random.Random

/** Что любит слушатель: считаем дослушивания, пропуски и лайки. Всё хранится только на телефоне. */
object Taste {
    class St(var plays: Int = 0, var completes: Int = 0, var skips: Int = 0, var last: Long = 0L)

    val stats = HashMap<Long, St>()
    val recent = ArrayList<Long>()   // последние сыгранные (новые в конце)
    private var sp: SharedPreferences? = null
    private var dirty = 0

    fun init(c: Context) {
        if (sp != null) return
        val s = c.getSharedPreferences("taste", Context.MODE_PRIVATE)
        sp = s
        try {
            val j = JSONObject(s.getString("stats", "{}") ?: "{}")
            for (k in j.keys()) {
                val a = j.getJSONArray(k)
                stats[k.toLong()] = St(a.getInt(0), a.getInt(1), a.getInt(2), a.getLong(3))
            }
        } catch (e: Exception) { }
        try {
            val r = JSONArray(s.getString("recent", "[]") ?: "[]")
            for (i in 0 until r.length()) recent.add(r.getLong(i))
        } catch (e: Exception) { }
    }

    fun save() {
        val e = sp?.edit() ?: return
        val j = JSONObject()
        for ((id, s) in stats) j.put(id.toString(), JSONArray(listOf(s.plays, s.completes, s.skips, s.last)))
        e.putString("stats", j.toString())
        e.putString("recent", JSONArray(recent).toString())
        e.apply()
    }

    /** Трек закончился или его сменили: ratio — какую долю успели прослушать. */
    fun onLeft(t: Track, ratio: Float) {
        val s = stats.getOrPut(t.id) { St() }
        s.plays++
        if (ratio >= 0.7f) s.completes++ else if (ratio < 0.25f) s.skips++
        s.last = System.currentTimeMillis()
        recent.remove(t.id)
        recent.add(t.id)
        while (recent.size > 40) recent.removeAt(0)
        if (++dirty >= 5) { save(); dirty = 0 }
    }

    fun dislike(t: Track) {
        stats.getOrPut(t.id) { St() }.skips += 3
        save()
    }

    fun reset() {
        stats.clear()
        recent.clear()
        save()
    }
}

/** «Моя волна»: бесконечная очередь, которая подстраивается под вкус и иногда добавляет новое. */
object Wave {
    val remoteById = HashMap<Long, Track>()
    private val pool = ArrayList<Track>()          // подобранные «открытия» из интернета
    @Volatile private var fetching = false
    var status by mutableStateOf("")

    private val genreMap = listOf(
        "hip" to "hiphop", "rap" to "hiphop", "rock" to "rock", "pop" to "pop", "electro" to "electronic",
        "dance" to "electronic", "house" to "house", "techno" to "techno", "metal" to "metal", "jazz" to "jazz",
        "class" to "classical", "indie" to "indie", "folk" to "folk", "chill" to "chillout", "ambient" to "ambient",
        "lounge" to "lounge", "punk" to "punkrock", "blues" to "blues", "reggae" to "reggae", "soul" to "soul",
        "funk" to "funk", "country" to "country", "latin" to "latin", "r&b" to "rnb", "rnb" to "rnb"
    )

    private fun aff(all: List<Track>, key: (Track) -> String): Map<String, Float> {
        val m = HashMap<String, Float>()
        for (t in all) {
            val k = key(t).lowercase()
            if (k.isBlank()) continue
            val s = Taste.stats[t.id]
            var v = if (t.id in Cfg.favs) 2.2f else 0f
            if (s != null) v += 0.5f * s.completes - 0.7f * s.skips
            if (v != 0f) m[k] = (m[k] ?: 0f) + v
        }
        for (k in m.keys.toList()) m[k] = tanh((m[k] ?: 0f) / 3f)
        return m
    }

    private fun score(t: Track, aa: Map<String, Float>, ga: Map<String, Float>): Float {
        val s = Taste.stats[t.id]
        var x = if (t.id in Cfg.favs) 2.0f else 0f
        if (s != null) x += 0.6f * min(s.completes, 6) - 0.9f * min(s.skips, 5) + 0.08f * min(s.plays, 12)
        x += 0.9f * (aa[t.artist.lowercase()] ?: 0f) + 0.5f * (ga[t.genre.lowercase()] ?: 0f)
        return x
    }

    /** Взвешенный выбор: нравящееся — чаще, недавнее и пропускаемое — реже, плюс доля нового. */
    private fun pick(all: List<Track>, n: Int, avoid: Set<Long>, lastArtistIn: String): List<Track> {
        val aa = aff(all) { it.artist }
        val ga = aff(all) { it.genre }
        val cand = all.filter { it.id !in avoid }.toMutableList()
        val out = ArrayList<Track>()
        var lastArtist = lastArtistIn
        for (step in 0 until n) {
            if (cand.isEmpty()) break
            val unplayed = cand.filter { Taste.stats[it.id] == null }
            val choice: Track
            if (unplayed.isNotEmpty() && Random.nextFloat() < Cfg.waveNovelty) {
                choice = unplayed.random()
            } else {
                val w = DoubleArray(cand.size) { i ->
                    val t = cand[i]
                    var ww = exp(score(t, aa, ga).toDouble()).coerceAtMost(1e6)
                    val ri = Taste.recent.lastIndexOf(t.id)
                    if (ri >= 0) ww *= if (Taste.recent.size - ri <= 10) 0.04 else 0.3
                    if (t.artist.isNotBlank() && t.artist.equals(lastArtist, true)) ww *= 0.15
                    ww
                }
                var r = Random.nextDouble() * w.sum()
                var idx = 0
                while (idx < w.size - 1 && r > w[idx]) { r -= w[idx]; idx++ }
                choice = cand[idx]
            }
            cand.remove(choice)
            out.add(choice)
            lastArtist = choice.artist
        }
        return out
    }

    /** Теги Jamendo по жанрам, которые слушатель любит больше всего. */
    private fun userTags(all: List<Track>): List<String> {
        val ga = aff(all) { it.genre }
        val count = HashMap<String, Float>()
        for (t in all) {
            val g = t.genre.lowercase()
            if (g.isBlank()) continue
            count[g] = (count[g] ?: 0f) + 1f + (ga[g] ?: 0f) * 3f
        }
        val tags = LinkedHashSet<String>()
        for (e in count.entries.sortedByDescending { it.value }) {
            for ((k, v) in genreMap) if (e.key.contains(k)) tags.add(v)
            if (tags.size >= 3) break
        }
        if (tags.isEmpty()) { tags.add("pop"); tags.add("electronic") }
        return tags.toList().take(3)
    }

    private fun batch(n: Int, avoid: Set<Long>, lastArtist: String): List<Track> {
        val local = pick(App.tracks, n, avoid, lastArtist)
        if (!Cfg.jamendoOn || Cfg.jamendoId.isBlank()) return local
        val out = ArrayList(local)
        var i = 2
        while (i < out.size) {
            val r = synchronized(pool) { if (pool.isEmpty()) null else pool.removeAt(0) } ?: break
            remoteById[r.id] = r
            out[i] = r
            i += 3   // каждый третий — «открытие»
        }
        return out
    }

    fun start(c: Context) {
        if (App.tracks.isEmpty()) { status = "Нет треков на телефоне"; return }
        status = ""
        App.waveOn = true
        val p = Audio.player
        val first = batch(12, emptySet(), "")
        p.setMediaItems(first.map { it.item() }, 0, 0L)
        p.shuffleModeEnabled = false
        p.repeatMode = 0
        p.prepare()
        p.play()
        refillRemote()
    }

    /** Подмешивает новые треки, когда в очереди остаётся мало. */
    fun topUp() {
        val p = Audio.player
        if (!App.waveOn || p.mediaItemCount == 0) return
        if (p.mediaItemCount - p.currentMediaItemIndex - 1 > 3) return
        val ids = HashSet<Long>()
        for (i in 0 until p.mediaItemCount) p.getMediaItemAt(i).mediaId.toLongOrNull()?.let { ids.add(it) }
        val last = p.getMediaItemAt(p.mediaItemCount - 1).mediaId.toLongOrNull()?.let { App.byId(it)?.artist } ?: ""
        p.addMediaItems(batch(8, ids, last).map { it.item() })
        if (synchronized(pool) { pool.size } < 6) refillRemote()
    }

    private fun refillRemote() {
        if (!Cfg.jamendoOn || Cfg.jamendoId.isBlank() || fetching) return
        fetching = true
        val tags = userTags(App.tracks)
        val cid = Cfg.jamendoId.trim()
        Thread {
            try {
                val l = Net.jamendo(cid, tags, 20)
                synchronized(pool) { for (t in l) if (pool.none { it.id == t.id }) pool.add(t) }
                status = if (l.isEmpty()) "Jamendo ничего не нашёл по тегам: " + tags.joinToString(", ") else ""
            } catch (e: Exception) {
                status = "Jamendo: " + (e.message ?: "ошибка")
            } finally {
                fetching = false
            }
        }.start()
    }
}
